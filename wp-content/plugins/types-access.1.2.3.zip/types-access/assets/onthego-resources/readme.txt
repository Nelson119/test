Usage:

cd "to a folder of your choice"

mkdir onthegosystems-icons

svn checkout https://www.onthegosystems.com/misc_svn/onthegosystems-branding/trunk/ onthegosystems-icons

cd onthegosystems-icons

fontcustom compile
